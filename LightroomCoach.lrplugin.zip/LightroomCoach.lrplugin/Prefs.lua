--[[----------------------------------------------------------------------------
Prefs.lua
Plugin preferences UI for API key configuration

© 2025 misterburton
------------------------------------------------------------------------------]]

local LrView = import 'LrView'
local LrPrefs = import 'LrPrefs'

local prefs = LrPrefs.prefsForPlugin()

return {
  sectionsForTopOfDialog = function(f, propertyTable)
    return {
      {
        title = "Gemini Configuration",
        bind_to_object = prefs,
        
        f:row {
          spacing = f:control_spacing(),
          f:static_text { 
            title = "Gemini API Key:",
            alignment = 'right',
            width = LrView.share 'label_width'
          },
          f:edit_field {
            value = LrView.bind("gemini_api_key"),
            width_in_chars = 50,
            immediate = true
          }
        },
        
        f:row {
          spacing = f:control_spacing(),
          f:static_text { 
            title = "",
            width = LrView.share 'label_width'
          },
          f:static_text {
            title = "Get your API key from aistudio.google.com",
            font = "<system/small>",
            text_color = import 'LrColor'(0.5, 0.5, 0.5)
          }
        }
      }
    }
  end
}

